package lite.apkx

import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.concurrent.thread

class MainActivity : Activity() {

    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pkgIn = EditText(this).apply {
            setText("com.sharp.aura")
            isSingleLine = true
        }
        val btn = Button(this).apply {
            text = "Извлечь"
            setOnClickListener { extract(pkgIn.text.toString().trim()) }
        }
        status = TextView(this).apply {
            text = "Введите имя пакета и нажмите «Извлечь».\nФайл появится в Загрузки/ApkOut."
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 96, 32, 32)
        }
        root.addView(pkgIn)
        root.addView(btn)
        root.addView(status)
        setContentView(root)
    }

    private fun extract(pkg: String) {
        status.text = "Работаю..."
        thread {
            val msg = try {
                val pi = packageManager.getPackageInfo(pkg, 0)
                val ai = pi.applicationInfo!!
                val files = ArrayList<File>()
                files.add(File(ai.sourceDir))
                ai.splitSourceDirs?.forEach { files.add(File(it)) }

                val name = "${pkg}_${pi.versionName}.zip"
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ApkOut")
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                    ?: error("Не удалось создать файл")

                contentResolver.openOutputStream(uri)!!.use { os ->
                    ZipOutputStream(os).use { zos ->
                        zos.setLevel(0)
                        for (f in files) {
                            zos.putNextEntry(ZipEntry(f.name))
                            f.inputStream().use { it.copyTo(zos) }
                            zos.closeEntry()
                        }
                    }
                }
                "Готово: Загрузки/ApkOut/$name\nAPK внутри: ${files.size} шт."
            } catch (e: PackageManager.NameNotFoundException) {
                "Приложение не найдено: $pkg"
            } catch (e: Exception) {
                "Ошибка: ${e.message}"
            }
            runOnUiThread { status.text = msg }
        }
    }
}
